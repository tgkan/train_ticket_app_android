package com.example.final_trainbookingticket.Activity;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.example.final_trainbookingticket.Model.Railways;
import com.example.final_trainbookingticket.R;
import com.example.final_trainbookingticket.databinding.ActivityTicketBinding;

public class TicketActivity extends BaseActivity {
    private ActivityTicketBinding binding;
    private Railways railway;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTicketBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getIntentExtra();
        setVariable();
    }

    private void setVariable() {
        binding.backBtn.setOnClickListener(v -> finish());
        binding.fromTxt.setText(railway.getFromShort());
        binding.toTxt.setText(railway.getToShort());
        binding.fromSmallTxt.setText(railway.getFrom());
        binding.toShortTxt.setText(railway.getTo());
        binding.toSmallTxt.setText(railway.getTo());
        binding.dateTxt.setText(railway.getDate());
        binding.timeTxt.setText(railway.getTime());
        binding.classTxt.setText(railway.getClassSeat());
        binding.seatsTxt.setText(railway.getPassenger());
        binding.priceTxt.setText("$" + railway.getPrice());
        binding.arrivalTxt.setText(railway.getArriveTime());
        binding.railwayTxt.setText(railway.getRailwayName());

//        Glide.with(TicketActivity.this)
//                .load(railway.getRailwayLogo())
//                .load(binding.logo);
    }

    private void getIntentExtra() {
        railway = (Railways) getIntent().getSerializableExtra("railway");
    }


}