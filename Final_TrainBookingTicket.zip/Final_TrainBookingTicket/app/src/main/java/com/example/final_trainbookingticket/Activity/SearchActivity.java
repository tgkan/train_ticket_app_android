package com.example.final_trainbookingticket.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.final_trainbookingticket.Adapter.RailwayAdapter;
import com.example.final_trainbookingticket.Model.Location;
import com.example.final_trainbookingticket.Model.Railways;
import com.example.final_trainbookingticket.R;
import com.example.final_trainbookingticket.databinding.ActivitySearchBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicMarkableReference;

public class SearchActivity extends BaseActivity {
    private ActivitySearchBinding binding;
    private String from, to, date;
    private int numPassenger = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        binding = ActivitySearchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getIntentExtra();
        initList();
        setVariable();
    }

    private void setVariable() {
        binding.searchView.setOnClickListener(v -> {
            Intent intent = new Intent(SearchActivity.this, SeatListActivity.class);
            startActivity(intent);
        });
        binding.backBtn.setOnClickListener(v -> {
            finish();
        });

    }

    private void initList() {
        DatabaseReference myRef = db.getReference("Railways");
        ArrayList<Railways> list = new ArrayList<>();
        Query query = myRef.orderByChild("from").equalTo(from);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    for(DataSnapshot issue:snapshot.getChildren()){
                        Railways railway = issue.getValue(Railways.class);
                        if(railway.getTo().equals(to)){
                            list.add(railway);
                        }

//                        if(railway.getTo().equals(to) && railway.getDate().equals(date)){
//                            list.add(railway);
//                        }
                        if(!list.isEmpty()){
                            binding.searchView.setLayoutManager(new LinearLayoutManager(SearchActivity.this, LinearLayoutManager.VERTICAL, false));
                            binding.searchView.setAdapter(new RailwayAdapter(list));
                        }

                        binding.progressBarSearch.setVisibility(View.GONE);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void getIntentExtra(){
        from = getIntent().getStringExtra("from");
        to = getIntent().getStringExtra("to");
        date = getIntent().getStringExtra("date");
        numPassenger = getIntent().getIntExtra("numPassenger", 0);
    }
}