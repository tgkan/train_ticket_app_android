package com.example.final_trainbookingticket.Model;

import java.io.Serializable;

public class Railways implements Serializable {
    private String railwayLogo;
    private String railwayName;
    private String arriveTime;
    private String classSeat;
    private String date;
    private String from;
    private String fromShort;
    private Integer numberSeat;
    private Double price;
    private String seats;
    private String reservedSeats;
    private String time;
    private String to;
    private String toShort;
    private String passenger;

    public Railways() {
    }

    @Override
    public String toString() {
        return from;
    }

    public String getRailwayLogo() {
        return railwayLogo;
    }

    public void setRailwayLogo(String railwayLogo) {
        this.railwayLogo = railwayLogo;
    }
    public String getPassenger() {
        return passenger;
    }
    public void setPassenger(String passenger) {
        this.passenger = passenger;
    }

    public String getRailwayName() {
        return railwayName;
    }

    public void setRailwayName(String railwayName) {
        this.railwayName = railwayName;
    }

    public String getArriveTime() {
        return arriveTime;
    }

    public void setArriveTime(String arriveTime) {
        this.arriveTime = arriveTime;
    }

    public String getClassSeat() {
        return classSeat;
    }

    public void setClassSeat(String classSeat) {
        this.classSeat = classSeat;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getFromShort() {
        return fromShort;
    }

    public void setFromShort(String fromShort) {
        this.fromShort = fromShort;
    }

    public Integer getNumberSeat() {
        return numberSeat;
    }

    public void setNumberSeat(Integer numberSeat) {
        this.numberSeat = numberSeat;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getSeats() {
        return seats;
    }

    public void setSeats(String seats) {
        this.seats = seats;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getReservedSeats() {
        return reservedSeats;
    }

    public void setReservedSeats(String reservedSeats) {
        this.reservedSeats = reservedSeats;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getToShort() {
        return toShort;
    }

    public void setToShort(String toShort) {
        this.toShort = toShort;
    }
}
