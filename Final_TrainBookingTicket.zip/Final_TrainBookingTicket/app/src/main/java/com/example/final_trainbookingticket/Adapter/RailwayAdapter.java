package com.example.final_trainbookingticket.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.final_trainbookingticket.Activity.SeatListActivity;
import com.example.final_trainbookingticket.Model.Railways;
import com.example.final_trainbookingticket.databinding.ViewholderRailwayBinding;

import java.util.ArrayList;

public class RailwayAdapter extends RecyclerView.Adapter<RailwayAdapter.Viewholder>{
    private final ArrayList<Railways> railways;
    private Context context;

    public RailwayAdapter(ArrayList<Railways> railways) {
        this.railways = railways;
    }


    @NonNull
    @Override
    public RailwayAdapter.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        context = parent.getContext();
        ViewholderRailwayBinding binding = ViewholderRailwayBinding.inflate(LayoutInflater.from(context), parent, false);
        return new Viewholder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RailwayAdapter.Viewholder holder, int position){
        Railways railway = railways.get(position);
        Glide.with(context)
                .load(railway.getRailwayLogo())
                .into(holder.binding.logo);

        holder.binding.fromTxt.setText(railway.getFrom());
        holder.binding.toTxt.setText(railway.getTo());
        holder.binding.fromShortTxt.setText(railway.getFrom());
        holder.binding.toShortTxt.setText(railway.getTo());
        holder.binding.arrivalTxt.setText(railway.getArriveTime());
        holder.binding.classTxt.setText(railway.getClassSeat());
        holder.binding.priceTxt.setText("$"+railway.getPrice());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, SeatListActivity.class);
            intent.putExtra("railway", railways);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount(){
        return railways.size();
    }
    public class Viewholder extends RecyclerView.ViewHolder {
        private final ViewholderRailwayBinding binding;
        public Viewholder(ViewholderRailwayBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
